import { useRef, useEffect } from "react";
import TranscriptViewer from "./TranscriptViewer";
import SummaryView from "./SummaryView";
import ChatPanel from "./ChatPanel";

/**
 * RightPanel — Smart panel that auto-switches content based on video state.
 *
 * When video is PLAYING:
 *   → Shows transcript with auto-scroll to current timestamp
 *
 * When video is PAUSED:
 *   → Restores the user's last active tab (summary / chat / transcript)
 *
 * Props:
 *   isPlaying    — boolean — video play state
 *   currentTime  — number (seconds)
 *   transcript   — array of { text, offset }
 *   summary      — string
 *   chatHistory  — array
 *   onSeek       — (seconds) => void
 *   question     — string
 *   setQuestion  — setter
 *   onAsk        — () => void
 *   askingAI     — boolean
 *   activeTab    — "summary" | "chat" | "transcript"
 *   setActiveTab — setter
 */
function RightPanel({
  isPlaying,
  currentTime,
  transcript,
  summary,
  chatHistory,
  onSeek,
  question,
  setQuestion,
  onAsk,
  askingAI,
  activeTab,
  setActiveTab,
}) {
  // Remember the tab user was on before playback started
  const savedTabRef = useRef(activeTab);

  useEffect(() => {
    if (isPlaying) {
      // Save the current tab before switching to transcript
      savedTabRef.current = activeTab;
    } else {
      // Restore saved tab when paused
      if (savedTabRef.current) {
        setActiveTab(savedTabRef.current);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isPlaying]);

  // During playback, always show transcript
  const showingTranscript = isPlaying;

  return (
    <div className="flex flex-col h-full min-h-0 overflow-hidden">
      {/* Panel Header */}
      <div className="flex items-center justify-between px-4 py-3 shrink-0 border-b border-border-subtle">
        {showingTranscript ? (
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-olive animate-pulse-soft" />
            <span className="text-xs font-medium text-olive uppercase tracking-wider">
              Now Playing — Following Transcript
            </span>
          </div>
        ) : (
          <span className="text-xs font-medium text-text-muted uppercase tracking-wider">
            {activeTab === "summary" && "📋 Summary"}
            {activeTab === "chat" && "💬 Chat"}
            {activeTab === "transcript" && "📝 Transcript"}
          </span>
        )}
      </div>

      {/* Panel Content */}
      <div className="flex-1 min-h-0 overflow-y-auto p-4">
        {showingTranscript ? (
          <TranscriptViewer
            transcript={transcript}
            onSeek={onSeek}
            currentTime={currentTime}
            isAutoScrolling={true}
          />
        ) : (
          <>
            {activeTab === "summary" && <SummaryView summary={summary} />}
            {activeTab === "chat" && (
              <ChatPanel
                chatHistory={chatHistory}
                question={question}
                setQuestion={setQuestion}
                onAsk={onAsk}
                askingAI={askingAI}
              />
            )}
            {activeTab === "transcript" && (
              <TranscriptViewer
                transcript={transcript}
                onSeek={onSeek}
                currentTime={currentTime}
                isAutoScrolling={false}
              />
            )}
          </>
        )}
      </div>
    </div>
  );
}

export default RightPanel;
