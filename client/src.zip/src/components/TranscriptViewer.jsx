import { useRef, useEffect, useMemo } from "react";

/**
 * TranscriptViewer — Displays transcript with auto-scroll and active highlighting.
 *
 * Props:
 *   transcript      — array of { text, offset (ms) }
 *   onSeek          — (seconds) => void — called when user clicks a timestamp
 *   currentTime     — number (seconds) — current video playback position
 *   isAutoScrolling — boolean — when true, auto-scroll to the active segment
 */
function TranscriptViewer({ transcript, onSeek, currentTime = 0, isAutoScrolling = false }) {
  const itemRefs = useRef([]);
  const containerRef = useRef(null);

  if (!transcript.length) return null;

  // Determine the active transcript index based on currentTime
  const activeIndex = useMemo(() => {
    if (!currentTime && currentTime !== 0) return -1;
    const timeSec = currentTime;
    let idx = -1;
    for (let i = 0; i < transcript.length; i++) {
      if (transcript[i].offset / 1000 <= timeSec) {
        idx = i;
      } else {
        break;
      }
    }
    return idx;
  }, [currentTime, transcript]);

  // Auto-scroll to active item
  useEffect(() => {
    if (isAutoScrolling && activeIndex >= 0 && itemRefs.current[activeIndex]) {
      itemRefs.current[activeIndex].scrollIntoView({
        behavior: "smooth",
        block: "center",
      });
    }
  }, [activeIndex, isAutoScrolling]);

  const formatTime = (ms) => {
    const totalSeconds = Math.floor(ms / 1000);
    const m = Math.floor(totalSeconds / 60);
    const s = totalSeconds % 60;
    return `${m}:${String(s).padStart(2, "0")}`;
  };

  return (
    <div ref={containerRef} className="flex flex-col" id="transcript-container">
      {transcript.map((item, index) => {
        const isActive = index === activeIndex;
        return (
          <div
            key={index}
            ref={(el) => (itemRefs.current[index] = el)}
            className={`
              flex gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 cursor-default
              ${isActive
                ? "bg-bg-active border-l-3 border-l-olive pl-3"
                : "hover:bg-bg-card-hover"
              }
            `}
          >
            <span
              className={`
                font-mono text-xs whitespace-nowrap pt-0.5 font-medium cursor-pointer
                transition-colors duration-150 shrink-0
                ${isActive ? "text-olive font-semibold" : "text-text-accent hover:text-olive-dark hover:underline"}
              `}
              onClick={() => onSeek(Math.floor(item.offset / 1000))}
              title="Click to jump to this point"
            >
              {formatTime(item.offset)}
            </span>
            <span
              className={`
                text-sm leading-relaxed
                ${isActive ? "text-text-primary font-medium" : "text-text-secondary"}
              `}
            >
              {item.text}
            </span>
          </div>
        );
      })}
    </div>
  );
}

export default TranscriptViewer;